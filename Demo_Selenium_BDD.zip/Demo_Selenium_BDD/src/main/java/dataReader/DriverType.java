package dataReader;
public enum DriverType {
	FIREFOX,
	CHROME,
	INTERNETEXPLORER,
	APPIUM
}