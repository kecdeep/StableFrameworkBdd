package dataReader;

public enum EnvironmentType {
	LOCAL,
	REMOTE,
}