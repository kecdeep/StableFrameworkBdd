package stepDefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import manager.TestContext;
import pages.HomePage;


public class HomePageSteps {
	
	TestContext testContext;
	HomePage homePage;
	public HomePageSteps(manager.TestContext context) {
		testContext = context;
		homePage = testContext.getPageObjectManager().getHomePage();
		

	}
	
	@Given("^user is on Home Page$")
	public void user_is_on_Home_Page(){
		homePage.navigateTo_HomePage();	
	}

	@When("^he search for “dress”$")
	public void he_search_for_dress() throws Throwable {
		homePage.perform_Search("Mobile");
	}

	@When("^choose to buy the first item$")
	public void choose_to_buy_the_first_item() throws Throwable {
	    
	}

	@When("^moves to checkout from mini cart$")
	public void moves_to_checkout_from_mini_cart() throws Throwable {
	 
	}

	@When("^enter personal details on checkout page$")
	public void enter_personal_details_on_checkout_page() throws Throwable {
	  
	}

	@When("^select same delivery address$")
	public void select_same_delivery_address() throws Throwable {
	   
	}

	@When("^select payment method as “check” payment$")
	public void select_payment_method_as_check_payment() throws Throwable {
	
	}

	@When("^place the order$")
	public void place_the_order() throws Throwable {
		testContext.getWebDriverManager().closeDriver();
	}


}
